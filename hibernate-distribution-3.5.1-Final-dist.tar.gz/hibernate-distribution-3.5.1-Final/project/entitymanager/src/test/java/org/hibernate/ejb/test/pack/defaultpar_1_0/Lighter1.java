//$Id: Lighter1.java 18259 2009-12-17 15:34:04Z epbernard $
package org.hibernate.ejb.test.pack.defaultpar_1_0;

/**
 * @author Emmanuel Bernard
 */
public class Lighter1 {
	public String name;
	public String power;
}