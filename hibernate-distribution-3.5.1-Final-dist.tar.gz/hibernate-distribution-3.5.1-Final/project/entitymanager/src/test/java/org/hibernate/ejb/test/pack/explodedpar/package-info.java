@NamedQuery(name = "allCarpet", query = "select c from Carpet c") package org.hibernate.ejb.test.pack.explodedpar;

import org.hibernate.annotations.NamedQuery;

