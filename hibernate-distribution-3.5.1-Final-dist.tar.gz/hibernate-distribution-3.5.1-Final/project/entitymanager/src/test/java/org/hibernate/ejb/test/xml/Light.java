//$Id: Light.java 15483 2008-11-03 14:25:59Z hardy.ferentschik $
package org.hibernate.ejb.test.xml;

/**
 * @author Emmanuel Bernard
 */
public class Light {
	public String name;
	public String power;
}
