@NamedQuery(name = "allMouse",
		query = "select m from ApplicationServer m")
package org.hibernate.ejb.test.pack.war;

import org.hibernate.annotations.NamedQuery;

