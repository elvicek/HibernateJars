//$Id: NoPackageEntity.java 15483 2008-11-03 14:25:59Z hardy.ferentschik $

/**
 * @author Emmanuel Bernard
 */
public class NoPackageEntity {
	private Integer id;
	private String name;
}
